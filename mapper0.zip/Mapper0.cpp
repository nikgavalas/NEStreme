//-----------------------------------------------------------------------------
// Name: Mapper0.cpp
// Desc: Memory mapper 0 plugin for Nestreme.
//-----------------------------------------------------------------------------


#include <windows.h>
#include "../../Cpu.h"
#include "../../Ppu.h"
#include "../../NESData.h"

// Variables to be saved.
NES6502* pCPU = NULL;
NESPPU*  pPPU = NULL;
BYTE*    pabyPRGROM = NULL;
BYTE*    pabyCHRROM = NULL;


//-----------------------------------------------------------------------------
// Name: OnLoad()
// Desc: Called when the ROM is initially loaded. This is where the pointers
//       to PRG-ROM and CHR-ROM should be initialized. Also, all the 
//       variables in the NESDATA structure should be saved here.
//-----------------------------------------------------------------------------
BOOL __declspec(dllexport) OnLoad(NESDATA* pNesData)
{
	pCPU = pNesData->pCPU;
	pPPU = pNesData->pPPU;
	pabyPRGROM = pNesData->pabyPRGROM;
	pabyCHRROM = pNesData->pabyCHRROM;

	return TRUE;
} // end OnLoad()


//-----------------------------------------------------------------------------
// Name: OnRead()
// Desc: Called when there is a read from PRG-ROM memory ($8000-$FFFF).
//-----------------------------------------------------------------------------
BYTE __declspec(dllexport) OnRead(WORD wAddress)
{
	// Return the byte.
	if (wAddress >= 0x8000 && wAddress < 0xC000)
		return pCPU->pbyPRGROMBank1[wAddress-0x8000];
	else if (wAddress >= 0xC000 && wAddress <= 0xFFFF)
		return pCPU->pbyPRGROMBank2[wAddress-0xC000];

	return 0;
} // end OnRead()


//-----------------------------------------------------------------------------
// Name: OnWrite()
// Desc: Called when there is a write to PRG-RAM memory ($8000-$FFFF).
//-----------------------------------------------------------------------------
BOOL __declspec(dllexport) OnWrite(WORD wAddress, BYTE byData)
{
	// Write the byte to PRG-RAM memory.
	if (wAddress >= 0x8000 && wAddress < 0xC000)
		pCPU->pbyPRGROMBank1[wAddress-0x8000] = byData;
	else if (wAddress >= 0xC000 && wAddress <= 0xFFFF)
		pCPU->pbyPRGROMBank2[wAddress-0xC000] = byData;

	return TRUE;
} // end OnWrite()