//-----------------------------------------------------------------------------
// Name: Mapper3.cpp
// Desc: Memory mapper 3 plugin for Nestreme.
//-----------------------------------------------------------------------------


#include <windows.h>
#include "../../Cpu.h"
#include "../../Ppu.h"
#include "../../NESData.h"

// Variables to be saved.
NES6502* pCPU = NULL;
NESPPU*  pPPU = NULL;
BYTE*    pabyPRGROM = NULL;
WORD     wNumPRGROMPages = 0;
BYTE*    pabyCHRROM = NULL;
WORD     wNumCHRROMPages = 0;


//-----------------------------------------------------------------------------
// Name: OnLoad()
// Desc: Called when the ROM is initially loaded. This is where the pointers
//       to PRG-ROM and CHR-ROM should be initialized. Also, all the 
//       variables in the NESDATA structure should be saved here.
//-----------------------------------------------------------------------------
BOOL __declspec(dllexport) OnLoad(NESDATA* pNesData)
{
	pCPU = pNesData->pCPU;
	pPPU = pNesData->pPPU;
	pabyPRGROM = pNesData->pabyPRGROM;
	wNumPRGROMPages = pNesData->wNumPRGROMPages;
	pabyCHRROM = pNesData->pabyCHRROM;
	wNumCHRROMPages = pNesData->wNumCHRROMPages;

	// When the cart is first started, the first 16K ROM bank in the cart
	// is loaded into $8000, and the LAST 16K ROM bank is loaded into
	// $C000. This last 16K bank is permanently "hard-wired" to $C000,
	// and it cannot be swapped.
	pCPU->pbyPRGROMBank1 = pabyPRGROM;
	pCPU->pbyPRGROMBank2 = pabyPRGROM + ((wNumPRGROMPages-1)*0x4000);

	return TRUE;
} // end OnLoad()


//-----------------------------------------------------------------------------
// Name: OnRead()
// Desc: Called when there is a read from PRG-ROM memory ($8000-$FFFF).
//-----------------------------------------------------------------------------
BYTE __declspec(dllexport) OnRead(WORD wAddress)
{
	// Return the byte.
	if (wAddress >= 0x8000 && wAddress < 0xC000)
		return pCPU->pbyPRGROMBank1[wAddress-0x8000];
	else if (wAddress >= 0xC000 && wAddress <= 0xFFFF)
		return pCPU->pbyPRGROMBank2[wAddress-0xC000];

	return 0;
} // end OnRead()


//-----------------------------------------------------------------------------
// Name: OnWrite()
// Desc: Called when there is a write to PRG-RAM memory ($8000-$FFFF).
//-----------------------------------------------------------------------------
BOOL __declspec(dllexport) OnWrite(WORD wAddress, BYTE byData)
{
	// When a byte is written to this area of memory we need to
	// switch the first PRG-RAM pointer to (value writen*0x4000)
	if (byData <= wNumPRGROMPages)
		pCPU->pbyPRGROMBank1 = pabyPRGROM + (byData*0x4000);

	return TRUE;
} // end OnWrite()